<?php


class model_component_generator extends model  {


}