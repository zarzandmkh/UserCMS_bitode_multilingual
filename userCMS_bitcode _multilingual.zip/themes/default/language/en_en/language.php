<?php 
	$data_language = array(
		'_main_page_header' => 'Welcome to UserCMS bitcode multilingual edition',
		'_choose_language'	=> 'Choose language'
	);

 ?>