<?php 
	$data_language = array(
		'_main_page_header' => 'Добро пожаловать в userCMS bitcode мультиязычная версия',
		'_choose_language'	=> 'Выберите язык'
	);

 ?>