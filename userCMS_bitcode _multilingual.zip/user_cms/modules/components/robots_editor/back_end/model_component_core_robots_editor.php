<?php 
class model_component_core_robots_editor extends model {
	
}