<?php

/**
* 	component for update CORE
*   VERSION 1.0
*/
class model_component_core_update {
	

}