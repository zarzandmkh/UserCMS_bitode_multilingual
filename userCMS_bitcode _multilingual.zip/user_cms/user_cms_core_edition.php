<?php 

define('USER_CMS_EDITION', 'bitcode multilingual');


/**
* edition core class
* класс для ядра сборки
*/
class user_cms_core_edition extends user_cms_core {
	
	# здесь код для изменения ядра системы



}


